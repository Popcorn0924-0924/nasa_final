//
//  nasaView.swift
//  NASA_00857202
//
//  Created by User02 on 2020/12/29.
//

import SwiftUI
import SwiftyJSON
import SDWebImageSwiftUI
import WebKit

struct nasaView: View {
    @ObservedObject var list = getsNasaData()
    var body: some View {
        
           List(list.datas){ i in
            
                            
                        
                        
                   HStack (spacing: 15) {
                    
                       VStack (alignment: .leading, spacing: 10) {
                           
                           Text(i.title)
                               .fontWeight(.heavy)
                           Text(i.desc)
                           .lineLimit(2)
                           
                       }
                    
                       
                       if i.image != ""{
                           
                           WebImage(url: URL(string: i.image)!, options: .highPriority, context: nil)
                            .resizable()
                            .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                            .offset(x: 10, y:0)
                            .frame(width: 120, height: 80, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                           
                           
                       }
                       
                   }.padding(.vertical, 15)
               }
           
    }
}

struct nasaView_Previews: PreviewProvider {
    static var previews: some View {
        nasaView()
    }
}
struct NasadataType : Codable,Identifiable {
    var id: String
    var title : String
    var desc : String
    var url : String
    var image : String
}

class getsNasaData : ObservableObject {
    
    @Published var datas = [NasadataType]()
    
    init() {
        
        let source = "https://api.nasa.gov/planetary/apod?api_key=oi3OoUFHt8kjHOPCzNLn2FKSndQb9uGa2PIaNBei&start_date=2020-09-24&end_date=2020-12-10"
        
        let url = URL(string: source)!
        
        let session = URLSession(configuration: .default)
        
        session.dataTask(with: url) { (data, _, err) in
            
            if err != nil {
                print((err?.localizedDescription)!)
                return
            }
            
            let json = try! JSON(data: data!)
            
            for i in json{
                
                
                let title = i.1["title"].stringValue
                let description = i.1["explanation"].stringValue
                let url = i.1["url"].stringValue
                let image = i.1["hdurl"].stringValue
                let id = i.1["data"].stringValue
                
                DispatchQueue.main.async {
                    self.datas.append(NasadataType( id: id,title: title, desc: description, url: url, image: image))
                }
            }
        }.resume()
    }
}

struct USANewswebView : UIViewRepresentable {
    
    var url : String
    
    func makeUIView(context: UIViewRepresentableContext<USANewswebView>) -> WKWebView{
        
        let view = WKWebView()
        view.load(URLRequest(url: URL(string: url)!))
        return view
    }
    
    func updateUIView(_ uiView: WKWebView, context: UIViewRepresentableContext<USANewswebView>) {
        
    }
}
