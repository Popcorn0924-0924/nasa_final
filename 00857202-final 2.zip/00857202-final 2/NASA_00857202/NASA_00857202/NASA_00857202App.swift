//
//  NASA_00857202App.swift
//  NASA_00857202
//
//  Created by User02 on 2020/12/29.
//

import SwiftUI

@main
struct NASA_00857202App: App {
    var body: some Scene {
        WindowGroup {
            appView()
        }
    }
}
