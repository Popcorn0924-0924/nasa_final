//
//  nasaRow.swift
//  NASA_00857202
//
//  Created by User08 on 2021/1/5.
//

import SwiftUI
import SwiftyJSON
import SDWebImageSwiftUI
import WebKit
struct nasaRow: View {
    @ObservedObject var getData=datas()
    var body: some View {
        
        NavigationView{
            Text("123")
            List(getData.jsonData){i in
                ListRow(title:i.title)
            }
            
        }.navigationTitle("Nasa")
    }
}



struct Nasadata : Identifiable,Decodable {
    var id: Int
    var title : String
    var explanation : String
    var hdurl : String
    var image : String
}

class datas: ObservableObject{
    @Published var jsonData = [Nasadata]()
    init() {
        let session=URLSession(configuration: .default)
        
        session.dataTask(with: URL(string: "https://api.nasa.gov/planetary/apod?api_key=oi3OoUFHt8kjHOPCzNLn2FKSndQb9uGa2PIaNBei&start_date=2020-09-24&end_date=2020-12-10")!) { (data, _, _)in
                do{
                    let fetch=try JSONDecoder().decode([Nasadata].self,from: data!)
                    DispatchQueue.main.async {
                        self.jsonData=fetch
                        print(fetch)
                        
                           
                    }
                }
                catch{
                    print(error.localizedDescription)
                }
        }.resume()
    }
}
struct ListRow :View{
    
    
    var title : String
    
    var body:some View{
        HStack  {
        
//            Animation(url:URL(string: url)).resizable().frame(width:60,height:60).clipShape(Circle()).shadow(radius(20))
            Text(title).fontWeight(.bold)
            
        }
    }
}
struct nasaRow_Previews: PreviewProvider {
    static var previews: some View {
        nasaRow()
    }
}
