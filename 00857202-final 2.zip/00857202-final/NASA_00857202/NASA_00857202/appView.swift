//
//  appView.swift
//  NASA_00857202
//
//  Created by User02 on 2020/12/29.
//

import SwiftUI

struct appView: View {
    var body: some View {
        TabView {
            
            nasaView()
                .tabItem {
                    Image(systemName: "nairasign.circle")
                    Text("nasa")
                    }
            imageView()
                .tabItem {
                    Image(systemName: "nairasign.circle")
                    Text("nasa")
                    }
            
            
        }
    }
}

struct appView_Previews: PreviewProvider {
    static var previews: some View {
        appView()
    }
}
