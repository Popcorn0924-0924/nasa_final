//
//  nasa.swift
//  NASA_00857202
//
//  Created by User02 on 2020/12/29.
//

import SwiftUI
struct nasa: View {
    @State var nasas:[NasaData]=[]
    var body: some View {
        List(nasas) { nasa in
            Text(nasa.date)
        }
        .onAppear(){
            Api().getNasa { (nasas) in
                self.nasas=nasas
            }
            
        }
    }
}



struct NasaData:Codable,Identifiable{
    var id=UUID()
    var date:String
    var explanation:String
    
}
class Api{
    func getNasa(completion:@escaping([NasaData])->()){
    guard let url=URL(string: "https://api.nasa.gov/planetary/apod?api_key=oi3OoUFHt8kjHOPCzNLn2FKSndQb9uGa2PIaNBei&start_date=2020-09-24&end_date=2020-12-10")else{return}
        URLSession.shared.dataTask(with: url){(data, _, _)in
            let nasas=try!JSONDecoder().decode([NasaData].self,from: data!)
            DispatchQueue.main.async {
                completion(nasas)
            }
        }
        .resume()
    }
    
}





struct nasa_Previews: PreviewProvider {
    static var previews: some View {
        nasa()
    }
}
