//
//  NasaList.swift
//  NASA_00857202
//
//  Created by User02 on 2020/12/31.
//

import SwiftUI
    
struct NasaList: View {
    @State var nasas:[NasaData]=[]
    var body: some View {
        List(nasas) { nasa in
            Text(nasa.date)
        }
        .onAppear(){
            Api().getNasa { (nasas) in
                self.nasas=nasas
            }
            
        }
    }
}

struct NasaList_Previews: PreviewProvider {
    static var previews: some View {
        NasaList()
    }
}
