//
//  nasa.swift
//  NASA_00857202
//
//  Created by User02 on 2020/12/29.
//

import SwiftUI


struct NasaData:Codable,Identifiable{
    var id=UUID()
    var date:String
    var explanation:String
    
}
class Api{
    func getNasa(completion:@escaping([NasaData])->()){
    guard let url=URL(string: "https://api.nasa.gov/planetary/apod?api_key=oi3OoUFHt8kjHOPCzNLn2FKSndQb9uGa2PIaNBei&start_date=2020-09-24&end_date=2020-12-10")else{return}
        URLSession.shared.dataTask(with: url){(data, _, _)in
            let nasas=try!JSONDecoder().decode([NasaData].self,from: data!)
            DispatchQueue.main.async {
                completion(nasas)
            }
        }
        .resume()
    }
    
}

